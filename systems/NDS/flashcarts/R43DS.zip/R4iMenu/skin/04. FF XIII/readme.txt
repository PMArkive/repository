Sound format (RAW)
Format:     8bit (signed)
SampleRate: 11025
Channel:    Mono