Thank you for downloading Beup Live!

Place the BEUP directory as it is in the root of your card.
It will have some default icons and avatars and a different keyboard.

You can place the file 'Beup Live 0.4.nds' (or the 'Beup Live 0.4.ds.gba') wherever you want.
Don't forget to patch Beup Live with DLDI in order to use your own Avatars, Icons and Keyboards.


-HtheB

for more information:
http://www.HtheB.com
http://beup.supercard.fr