-firmware 1.96.8
 1. add support for 0870 - Super Robot Taisen W 
 2. update the compatibility of homebrew : moonshell ..etc 

-ewin2 firmware v1.92.6R

Total new graphical user interface
completely support touch
fully automatism aptitude loading process, quicker than before
"help" button adjust to "select", the fuction of delete original file cancel transitorily
add the fuction of "Y" force start up,should be use together with Ewin tool 1.2 in operation.
indicate the dosage of batteries.

-ewin2 firmware v1.91.8
optimize the speed of loading,
improve the compatibility of SD card
Support Jap vision
solved problem when load Pokemon

-Upgrade method:
1.choose your preferred language kernel vision

cht\EWIN_UPDATE.DAT  traditional chinese
chn\EWIN_UPDATE.DAT  simple chinese
eng\EWIN_UPDATE.DAT  English

2.upgrade operation
1.72 to 1.92  press "L+R+UP" to update to system
1.50,1.66 to 1.90  press "START" to finish the upgrade