EDGE OS v1.11
=============

EDGE Official Website: http://www.edge-ds.cn/

How to use
----------

To upgrade your EDGE OS, simply extract the contents of this archive to the
root directory of your MicroSD card, overwriting any older files.

Change log
----------

- v1.11 (10/6/2010)

  * Game compatibility fixes (DSi 0047, DSi 0054, 4341, 4716, 4723, 4726, 
    4778, 4831, 4851, 4856, 4868, 4883, 4900, 4904, 4913, 4916)

- v1.10 (19/4/2010)

  * Game compatibility fixes (4341, 4716, 4723, 4726, 4769, 4778, DSi 0047)

- v1.9 (16/3/2010)

  * Fix for "argv" information passed to homebrew software
  * Fixed save size for 4323, 4568
  * Game compatibility fixes (DSi 0040, 4356, 4747, 4748)

- v1.8 (3/3/2010)

  * Game compatibility fixes (4252, 4340, 4510, 4644, 4646, 4663, 4666, 4702,
    4708 and more)

- v1.7 (19/1/2010)

  * Many game compatibility fixes (DSi 0010, DSi 0015, DSi 0021, DSi 0025, 
    3212, 3499, 3541, 4207, 4280, 4362, 4417, 4447, 4472, 4482, 4492, 4506,
    4513, 4522, 4550, 4565, 4571, 4581, 4587, 4622 and more)

- v1.6 (2/12/2009)

  * Many game compatibility fixes, including but not limited to:
    3966, 4125, 4159, 4160, 4162, 4177, 4262, 4323

- v1.5 (4/8/2009)

  * Completely new and improved cheat code engine
  * Automatic ROM protection patcher
  * "argv" passed to homebrew software
  * DSL/DSi hybrid games are now supported (3938, 3949)
  * Many game compatibility fixes, including but not limited to:
    3538, 3607, 3690, 3812, 3872, 3874

- v1.45 (16/3/2009)

  * Game compatibility fix (3517)

- v1.44 (20/2/2009)

  * Automatic browser RAM patching supported with EZ3in1+
  * Problems with some kiosk demos resolved
  * Game compatibility fixes (3070, 3211, 3223, 3268, 3332, 3151, 3369, 3396)

- v1.43 (13/1/2009)

  * Game compatibility fixes (2625, 2746, 2822, 3191)

- v1.42 (1/12/2008)

  * Game compatibility fixes (2796, 2838, 2949, 3049, 3054) 

- v1.41 (6/10/2008)

  * SlowMotion feature added, hold L + R + DOWN + B for 1 second
    in-game to toggle on and off
  * Updated the cheat code database file

- v1.4 (23/8/2008)

  * Game compatibility fixes (2436, 2472, 2540)
  * Automatic rumble support for EZ3in1
  * Automatic Opera Browser RAM patching for EZ3in1
  * Updated the cheat code database file

- v1.37 (27/6/2008)

  * Game compatibility fix (2385)

- v1.36 (11/6/2008)

  * Fixed a minor graphical problem with the cheat code list

- v1.35 (10/6/2008)

  * Game compatibility fix (2343)
  * Miniaturized game icons are shown in list view
  * Updated the cheat code database file

- v1.34 (30/4/2008)

  * iQue games are now supported on regular NDS units
  * Slot 2 can now be booted in either NDS or GBA mode

- v1.33 (6/4/2008)

  * Game compatibility fixes (2203 + others)
  * Updated the cheat code database file

- v1.32 (3/3/2008)

  * Added new languages: Chinese Traditional, Spanish, Latin American
    Spanish and Portuguese
  * Updated the cheat code database file
    
- v1.31 (24/2/2008)

  * Game compatibility fixes
  * Skinning system enabled
  * Japanese GUI translation added
  * Moonshell soft reset support added (you must download the latest
    EDGE Moonshell build to take advantage of this)
