[English]
Important: If you are not using XMENU system, please backup your game and save first before upgrade to this firmware and XMENU system.

Q:How to upgrade the firmware of Ultra FlashPass EX?
Important: Firmware 1.45 need to work with XMENU 2.53 together. Please make sure you upgrade them both.

*** Upgrade Method 1 (recommend):
1. Copy ONLY "ufpex_eng_1_40.nds" into the Ultra FlashPass EX. Please do NOT replace the xment.dat at this moment.
2. Run it like a game from Ultra FashPass EX Menu.
3. When message appear, press A continue upgrade.
4. Turn off power and turn it on again, ENTER USB MODE.
5. Now, you can Copy "DSYSTEM" directory and "xmenu.dat" to Ultra FlashPass EX, and replace the old one.

*** Upgrade Method 2:
1.Insert Ultra Fire Line into slot 2 and insert Ultra FlashPass EX into slot 1.
2.Use USB cable connect to PC USB port directly. (Please do not use extension USB cable)
3.Hold the "up" directionnal button and turn on power.
4.still holding "up", press "L+R+A+B", will enter upgrade mode(red color text).
5.Double click "UFPEX_ALL.bat"to run upgrade program. Please ignore if there some "found a badblock" appear when upgrade some 8G Ultra FlashPass EX.
6.If you upgrade from a none XMENU system, you need to Quick Format Ultra FlashPass EX(method list below).
7.Open power again, and enter USB MODE, Copy "DSYSTEM" directory and "xmenu.dat" to Ultra FlashPass EX. 

Q: How to "QUICK FORMAT" Ultra FlashPass EX? 
1. Insert Ultra FlashPass EX Writer into slot 2 and insert Ultra FlashPass EX into slo 1.
2. Holding "L+R+A+B+DOWN" to enter Ultra FlashPass EX system, will enter quick format program mode.

Q: How to "FULL FORMAT" Ultra FlashPass EX? (Full format need more than 10mins, because of writting test)
1. Insert Ultra FlashPass EX Writer into slot 2 and insert Ultra FlashPass EX into slo 1.
2. Holding "L+R+Select+START+UP" when enter Ultra FlashPass EX System, will enter FULL format program mode.

****************
* Tips: I suggest Ultra FlashPass EX user make a FULL format, if there is something wrong with the Ultra FlashPass EX.(one time FULL format is enough)

* Tips: hole "Select+START" when enter Ultra FlashPass EX System, will enter to the format menu"
- Cancel
- Quick Format
- Full Format <- If the Ultra FlashPass EX is already full format before, it will not dispaly.
****************

Useful suggestion:
1. 98\win2000 user should "eject" the udisk safely before close the DS, because 98\win2000 background program still writting the flash after finish copy files, otherwise it maybe corrupt the fat of Ultra FlashPass EX.
2. winxp user should wait 3 seconds after finish copy files, otherwise it maybe corrupt the FAT of Ultra FlashPass EX.
3. At USB mode, if the text flashing red color, that mean writting the Ultra FlashPass EX, please do not turn off the power, otherwise it maybe corrupt the FAT of Ultra FlashPass EX.
4. If chkdsk program can not fix the FAT error, use Ultra FlashPass EX quick format can recover.
5. Do NOT format the Ultra FlashPass EX by windows, it will slow down the UDisk system. Use Ultra FlashPass EX quick format can recover.
6. Suggest use "SD Formatter V2.0" to format Ultra FlashPass EX, can be download from www.sdcard.org
7. Japanese, Trandition Chinese support. Copy Moonshell system.fon system.12u system.ank to DSYSTEM
8. I suggest Ultra FlashPass EX user make a FULL format before use it. Full format need more than 10mins, because of writting test
9. Battery test hold key change to "L+R+SELECT" when enter Ultra FlashPass EX System.