M3 Sakura v1.49X 3nd Edition (M31)
TouchPod v4.9 (M73)
=================================================
Change Log: 
	- [18 February, 2011] M3 Sakurka 1.49 3rd Edition Update
	- [15 February, 2011] Cheat file update
	- [21 December, 2010] M3 Sakura 1.49 2nd Edition Update
	- [20 December, 2010] TouchPod 4.9 update
	- [21 September, 2010] M3 Sakura 1.48X/TouchPod 4.8fX update
	- [25 July, 2010] Cheat file update
	- [20 July, 2010] M3 Sakura 1.48X update
	- [01 July, 2010] M3 Sakura 1.47X 4th Edition update
	- [01 July, 2010] TouchPod 4.8cX update
	- [01 July, 2010] Cheat file update
	- [16 May, 2010] M3 Sakura 1.47X 3rd Edition update
	- [13 May, 2010] TouchPod 4.8bX update
	- [23 April, 2010] M3 Sakura 1.47X 2nd Edition update
	- [21 April, 2010] TouchPod 4.8aX update
	- [17 April, 2010] Cheat file update
	- [01 April, 2010] Cheat file update
	- [27 March, 2010] M3 Sakura 1.47X update
	- [24 March, 2010] TouchPod 4.8X update
	- [06 March, 2010] M3 Sakura 1.46X 2nd Edition update
	- [05 March, 2010] TouchPod 4.7hX update
=================================================
M3 Sakura is a loader for the M3 Real and M3i Zero flashcarts.  

For more info on M3 Sakura, check the M3 Sakura FAQ at GBAtemp:
bit.ly/M3Sakura

Instructions:
Copy the SYSTEM folder to the root of your MicroSD card.  That's pretty much it!  

M3 Sakura language file translators:
- messages.000	English		By Densetsu3000
- messages.001	French		Revised by A-suuga
- messages.002	German		Revised by powered_by_tux and Zerrix
- messages.003	Italian 		By dragonball75, gosp and pesi
- messages.004	Spanish		Revised by Nagaroth and GaciX 69
- messages.005	Portuguese	By Denison Guizelini and Axel-MaV
- messages.006	Dutch		Revised by Grovyle91

Notice:
Some websites in the past have attempted to host this file with all references to GBAtemp and all translation credits removed.  While this doesn't really bother me, I still think that the others who worked on translating Sakura deserve to be recognized for their efforts.  M3 Sakura was translated from the original Japanese by members of GBAtemp.net, and the first English version was hosted on GBAtemp.net.  If you find this file on any other website with the above credits removed, I really don't care and I'm in no position to pursue any legal action (not that I would bother even if I could =P).  But just so you know, this was originally localized by GBAtemp members (the first iteration of M3 Sakura was localized by iamanobody, NeoGunKuruma, Toni Plutonij, mercenary96, thedicemaster, AXYPB, and myself).  The localized file was hosted on GBAtemp first.  Happy gaming!  

~ Densetsu3000