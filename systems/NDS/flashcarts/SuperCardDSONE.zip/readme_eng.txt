Update: 2010-10-16
1, Fixed file system (fixed the crash bug when there is space in filename)
2, Fixed Kingdom Hearts Recoded
3, Fixed Dementium 2(JP&EU)
4, Added AP manually set (Press Y to call out game info menu and turn on/off it. Default as Enable.)

update: 2010-08-21
1, Fixed the crush bug of Brain Age Series
2, Fixed the crush bug of Animal Crossing Chinese translated version.
3, Added the rumble, browser funcation(set in the system menu) for slot-2 series, supports SC slot-2 carts and 3in1 cart.
4, optimized read speed.

Date:2010-08-06
1. Fixed 5140 Galaxy Racers reading save data error problem.
2. Fixed 0856 Bleach 2nd can not save problem.
3. Fixed 5116 Keshikasu Japanese version (clean mode)
4. Fixed the cheat code blank list problem in some games. 
5. Added GBA linkage function.
Q: How to use GBA linkage function?
A: Usage: NAME.nds, NAME.nds.gba, NAME.nds.gba.sav. These three files are DS game file, GBA game file, GBA game save. NAME which can be user defined. This feature is selected by the user to open, choose the interface in the  start menu, select System Settings option.
6. Added the WII linkage functions.
7. Added support ez3 in 1,  superCard lite, superCard MINI SD, superCard SD, superCard CF
8. Added prevent halt in Castlevania: Portrait of Ruin.

Date: 2010.06.18
1. the Fix is only the OS (no other game files), the boot hang problem

Date: 2010.06.07
1. Fixed blank screen when turn on cheat code function.
2. Fixed diy shin crash problem (hotkey setting)
3. Fixed crash problem when setting language to French.

Date :2010-06-01
For performance improve:
1, Anti-Piracy system upgrade, added new anti-piracy Engine.
2, Fixed some games problem:
GameWatch Game Collection
4825 - Saku Saku Jinkou Kokyuu Care Training (J)
4877 - How to Train Your Dragon (can not save)
4900 - Dragon Quest Monsters Posts joker2 (J)
4933 - Dementium 2 (U)
4951 - Are You Smarter than a 5th Grader? Game Time
4958 - Captain Tsubasa: Gekito No Kiseki(J)
4963 - Super Robot Taisen OG Saga Masou Kishin THE LORD OF ELEMENTAL (J)
4967 - Create Club DS: World Challenge 2010 (J)
         - States husband's super-blood! Plus Football League

 Clean mode
4952 - Prince of Persia: The Forgotten Sands (E)

For UI update:
1, The skin can customize their own
2, Added the hot key customize defined

Note: Old version patch database can not be use in new OS.