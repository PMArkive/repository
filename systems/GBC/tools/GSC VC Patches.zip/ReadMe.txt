Pok�mon Wireless Communication Patches for Nintendo 3DS (XL), New 3DS (XL) & 2DS - Works to FW 11.2!
*v1.3*

for

Pok�mon Crystal
Pok�mon Gold
Pok�mon Silver
Pok�mon ROM Hacks


by TheStoneBanana & Traiver - gbatemp.net, 12/25/2016


Downloads:

Braindump: https://github.com/neobrain/braindump/releases
CTRTool: https://github.com/profi200/Project_CTR/releases
3DSTool: https://github.com/dnasdw/3dstool/releases
PackHack: http://www54.zippyshare.com/v/WuoiDBLr/file.html


Report bugs and glitches here:

http://gbatemp.net/threads/release-pokemon-gold-silver-and-crystal-virtual-console-wireless-linking-patches.439986/


Info:

Make sure you only use the wireless function once, after using it once, you must restart
both games to get it work again.


This package contains the patches for the following games:

- Crystal (English, German, Spanish, French)
- Gold/Silver (English, German, Spanish, French)
- Bronze Hack (English)
- Crystal Emu Edition - 251 Hack (English)
- Crystal Kaizo (English)
- Prism v0.91 (English)


Reminder: You simply can play Pok�mon Gold/Silver/Bronze in color or b/w. Just open the .patch file, scroll to the end and
change the number to 00 (b/w) or 80 (color).


Instructions:


1. Dump your copy of either Pokemon Red, Blue, Yellow, or Green using Braindump. Once complete, eject the SD card, and find a file with a title ID and .cxi extension on the SD card.
2. Take this .cxi to a safe place and write down the title ID somewhere.
3. Download CTRTool, and then place it into the folder with the .cxi file.
4. While in the folder, hold the SHIFT key and right click. You will see an option in the menu that appears called 'Open command window here'. Click on it.
5. Type the following:


ctrtool --exefs=exefs.bin --romfs=romfs.bin PUTTITLEIDHERE.cxi
ctrtool --romfsdir=romfs romfs.bin


And then...

1. Get yourself a ROM image of the game that you want to use the patch for, and then put it somewhere safe. (GBC Pokemon game ROMs aren't too hard to find online nowadays ;) )
2. Download the VC Patch Pack linked above.
3. Locate the appropriate patch for your ROM, as well as for the language of your ROM. (For example, if you're using the German version of Crystal, you'd find 'germancrystal.bin.patch'.)
4. Extract the appropriate patch and keep it somewhere safe with the ROM.
5. Rename the ROM to match the patch NOT INCLUDING the .patch ending.
6. Open up the extracted RomFS of your copy of Pokemon Red/Blue/Yellow/Green.
7. Delete all of the files in the root of the RomFS with the extension of '.patch'. (This just saves space for the long run. You can skip this step if you want to.)
8. Place the new '.patch' file from somewhere safe into the root of the RomFS.
9. Go into the RomFS's 'rom' folder.
10.Delete whatever file is inside and replace it with the ROM you have from somewhere safe.
11.If you're going to be using Pokemon Gold and Silver, listen closely. Otherwise, skip ahead to Step 15.
12.Go back to the root of the RomFS and open up the patch file in a text editor.
13.Go to the very last patch at the bottom of the file.
14.Decide now whether you want to play the game in DMG (Original Gameboy) mode or GBC (Gameboy Color) mode. If you want to play DMG mode, leave the patch as is and exit. Otherwise, change the "Fixcode" to 0x80.
15.Exit out of the RomFS entirely and move into the ExeFS.
16.Find the 'code.bin' within the ExeFS.
17.Using 3DSTool, decompress the code using the following command in CMD:


3dstool -uf code.bin --compress-type blz --compress-out decompressed_code.bin


1. Using a hex editor (doesn't matter which one), go to address 0x96EB7 and change the value to 0xE1. Save, and then recompress the code using this command in CMD:


3dstool -zf decompressed_code.bin --compress-type blz --compress-out code.bin


1. Your 'code.bin' has now been fixed so that colors display properly. Go ahead and delete 'decompressed_code.bin' and copy 'code.bin' to somewhere safe.
2. Rebuild your RomFS using the RomFS Builder in Pack Hack. (you need to open up SetupUS.exe, and then HackingToolkit3DS.exe, and in HackingToolkit3DS.exe type RFSB)
3. Export the newly built RomFS with a name of the last 8 digits of the Title ID you were supposed to write down earlier and the extension of '.romfs'.
4. If you don't already have it, make a folder called 'hans' on the root of your SD, and then copy the build .romfs file into said folder.
5. Take the 'code.bin' from earlier and rename it to the last 8 digits of the Title ID you were supposed to write down, along with the extension of '.code'. Copy this to the 'hans' folder on the SD card, as well.
6. Eject your SD card, put it back into the 3DS, and load up the Homebrew Launcher.
7. Run HANS, selecting the Pokemon game that you dumped earlier.
8. On the HANS menu, change the 'RomFS' option to 'YES', change the 'Code' option to 'YES', and then boot into the game. (You're probably going to want to save the configuration for later)

Phew! Congratulations! It was a lot of work, but now you're finally ready to use this newfangled patch on your game!
Whenever you go to use a linking function within the game, the Wireless Connection menu should automatically pop up. From here, you should know what to do.


Troubleshooting:

Q: Why are the colors freaking out? Sometimes they're blank, and other times, they're flashy!
A: You didn't follow the steps correctly for patching the 'code.bin'. Go back and try again.

Q: *a general issue that's probably a bug*
A: Report it to me either through this thread or through PM and I'll take a look.

Credits:

@TheStoneBanana (me!) for researching and writing the new patch for Pokemon Crystal.
@Pandaxclone2, @darkalex004, and @Traiver for testing the original patch(es) to death.
@Traiver for porting my original patch to Pokemon Silver, Gold, and the Bronze ROM hack, as well as porting it to support other languages.